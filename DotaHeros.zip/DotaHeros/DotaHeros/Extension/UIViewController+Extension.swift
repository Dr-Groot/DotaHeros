//
//  UIViewController+Extension.swift
//  DotaHeros
//
//  Created by Amam Pratap Singh on 16/02/23.
//

import UIKit
import NVActivityIndicatorView

extension UIViewController {
    func showLoader(indicatorColor: UIColor = .systemMint) {
        let activityData = ActivityData(type: .circleStrokeSpin, color: indicatorColor)
        NVActivityIndicatorPresenter.sharedInstance.startAnimating(activityData, nil)
    }

    func hideLoader() {
        NVActivityIndicatorPresenter.sharedInstance.stopAnimating(nil)
    }

}
