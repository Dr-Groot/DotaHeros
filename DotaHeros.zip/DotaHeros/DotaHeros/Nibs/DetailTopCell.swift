//
//  DetailTopCell.swift
//  DotaHeros
//
//  Created by Amam Pratap Singh on 16/02/23.
//

import UIKit
import Reusable
import SkeletonView
import Kingfisher

class DetailTopCell: UITableViewCell, NibReusable {

    @IBOutlet var nameLabel: UILabel!
    @IBOutlet var primaryAttr: UILabel!
    @IBOutlet var attackType: UILabel!
    @IBOutlet var primaryAttrValue: UILabel!
    @IBOutlet var attackTypeValue: UILabel!
    @IBOutlet var heroImageView: UIImageView!
    @IBOutlet var heroMiniImageView: UIImageView!

    override func awakeFromNib() {
        super.awakeFromNib()

        configTheme()
        configDependencies()
    }

    private func configTheme() {
        primaryAttr.text = "Primary Attribute"
        attackType.text = "Attack Type"
        heroImageView.isSkeletonable = true
    }

    private func configDependencies() {
        let gradient = SkeletonGradient(baseColor: .wisteria)
        heroImageView.showAnimatedGradientSkeleton(usingGradient: gradient, transition: .crossDissolve(0.5))
    }

    func setValue(data: HeroElement) {
        nameLabel.text = data.localizedName
        primaryAttrValue.text = data.primaryAttr
        attackTypeValue.text = data.attackType
        heroImageView.kf.setImage(
            with: URL(string: "https://api.opendota.com\(data.img)"),
            completionHandler: { result in
                switch result {
                case .success:
                    self.heroImageView.hideSkeleton()
                    self.heroImageView.layer.borderWidth = 3
                    self.heroImageView.layer.borderColor = UIColor.red.cgColor
                case .failure:
                    print("Unable to load hero image")
                }
        })
        heroMiniImageView.kf.setImage(with: URL(string: "https://api.opendota.com\(data.icon)"))
    }
}
