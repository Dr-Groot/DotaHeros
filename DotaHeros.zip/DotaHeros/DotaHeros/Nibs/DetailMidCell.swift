//
//  DetailMidCell.swift
//  DotaHeros
//
//  Created by Amam Pratap Singh on 16/02/23.
//

import UIKit
import Reusable

class DetailMidCell: UITableViewCell, NibReusable {

    @IBOutlet var roles: UILabel!
    @IBOutlet var baseHealth: UILabel!
    @IBOutlet var baseHealthRegen: UILabel!
    @IBOutlet var baseMana: UILabel!
    @IBOutlet var attackMax: UILabel!
    @IBOutlet var attackMin: UILabel!
    @IBOutlet var baseStr: UILabel!
    @IBOutlet var baseAgi: UILabel!
    @IBOutlet var baseInt: UILabel!
    @IBOutlet var StrGain: UILabel!
    @IBOutlet var AgiGain: UILabel!
    @IBOutlet var IntGain: UILabel!
    @IBOutlet var AttackRange: UILabel!
    @IBOutlet var ProjectileSpeed: UILabel!
    @IBOutlet var cardView: UIView!
    @IBOutlet var attackRate: UILabel!
    @IBOutlet var moveSpeed: UILabel!
    @IBOutlet var turnRate: UILabel!
    @IBOutlet var legs: UILabel!
    @IBOutlet var turboPick: UILabel!
    @IBOutlet var turboWins: UILabel!
    @IBOutlet var proWin: UILabel!
    @IBOutlet var proPick: UILabel!
    @IBOutlet var proBan: UILabel!
    @IBOutlet var nullPick: UILabel!
    

    override func awakeFromNib() {
        super.awakeFromNib()

        cardView.backgroundColor = .red
        cardView.layer.cornerRadius = 10
    }

    func setValue(data: HeroElement) {
        var str = ""
        for c in data.roles {
            str.append(contentsOf: c + "||")
        }
        roles.text = str
        baseHealth.text = "\(data.baseHealth)"
        baseHealthRegen.text = "\(data.baseHealthRegen)"
        baseMana.text = "\(data.baseMana)"
        attackMax.text = "\(data.baseAttackMax)"
        attackMin.text = "\(data.baseAttackMin)"
        baseStr.text = "\(data.baseStr)"
        baseAgi.text = "\(data.baseAgi)"
        baseInt.text = "\(data.baseInt)"
        StrGain.text = "\(data.strGain)"
        AgiGain.text = "\(data.agiGain)"
        IntGain.text = "\(data.intGain)"
        AttackRange.text = "\(data.attackRange)"
        ProjectileSpeed.text = "\(data.projectileSpeed)"
        attackRate.text = "\(data.attackRate)"
        moveSpeed.text = "\(data.moveSpeed)"
        turnRate.text = "\(data.turnRate ?? 0)"
        legs.text = "\(data.legs)"
        turboPick.text = "\(data.turboPicks)"
        turboWins.text = "\(data.turboWINS)"
        proPick.text = "\(data.proPick ?? 0)"
        proBan.text = "\(data.proBan)"
        nullPick.text = "\(data.nullPick)"
        proWin.text = "\(data.proWin ?? 0)"
    }
}
