//
//  DotaHeroCell.swift
//  DotaHeros
//
//  Created by Amam Pratap Singh on 16/02/23.
//

import UIKit
import Reusable
import Kingfisher

class DotaHeroCell: UITableViewCell, NibReusable {

    @IBOutlet var descriptionLabel: UILabel!
    @IBOutlet var nameLabel: UILabel!
    @IBOutlet var profileImage: UIImageView!

    var tapOpenButton: (() -> Void)?

    override func awakeFromNib() {
        super.awakeFromNib()

    }

    func setData(name: String, description: String, Image: String) {
        nameLabel.text = name
        descriptionLabel.text = description
        profileImage.kf.setImage(with: URL(string: Image))
    }

    @IBAction func didTapOpenButton(_ sender: UIButton) {
        tapOpenButton?()
    }

}
