//
//  ApiRequest.swift
//  DotaHeros
//
//  Created by Amam Pratap Singh on 16/02/23.
//

import Foundation

enum ApiRequestStatus {
    case idle
    case progress
    case success
    case error
}
