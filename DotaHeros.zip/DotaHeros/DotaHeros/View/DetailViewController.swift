//
//  DetailViewController.swift
//  DotaHeros
//
//  Created by Amam Pratap Singh on 16/02/23.
//

import UIKit

class DetailViewController: UIViewController {

    @IBOutlet var detialTableView: UITableView!

    var heroData: HeroElement?

    override func viewDidLoad() {
        super.viewDidLoad()

        configTheme()
        configDependencies()
    }

    private func configTheme() {}

    private func configDependencies() {
        detialTableView.register(cellType: DetailTopCell.self)

        detialTableView.register(cellType: DetailMidCell.self)

        detialTableView.delegate = self
        detialTableView.dataSource = self
    }

}

extension DetailViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 2
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.row == 0 {
            let cell = tableView.dequeueReusableCell(for: indexPath, cellType: DetailTopCell.self)
            cell.setValue(data: heroData ?? .default)
            return cell
        } else {
            let cell = tableView.dequeueReusableCell(for: indexPath, cellType: DetailMidCell.self)
            cell.setValue(data: heroData ?? .default)
            return cell
        }
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.row == 0 {
            return 380
        } else {
            return UITableView.automaticDimension
        }
    }
}
