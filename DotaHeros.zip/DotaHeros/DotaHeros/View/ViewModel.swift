//
//  ViewModel.swift
//  DotaHeros
//
//  Created by Amam Pratap Singh on 16/02/23.
//

import Foundation
import Moya
import RxSwift
import RxCocoa

class DotaViewModel {

    let dotaApiStatus: BehaviorRelay<ApiRequestStatus> = BehaviorRelay<ApiRequestStatus>(value: .idle)
    let dotaData: BehaviorRelay<HERO?> = BehaviorRelay<HERO?>(value: nil)

    private let disposeBag = DisposeBag()
    let provider = MoyaProvider<DotaService>()

    func callDotaApi() {
        dotaApiStatus.accept(.progress)

        provider.rx.request(.heroStats).subscribe({ event in
            switch event {
            case let .success(response):
                do {
                    let decoder = JSONDecoder()
                    let data = try decoder.decode(HERO.self, from: response.data)
                    self.dotaData.accept(data)
                } catch {
                    print("Getting error while loading data")
                }
                self.dotaApiStatus.accept(.success)
            case .failure:
                print("Not able to load api")
                self.dotaApiStatus.accept(.error)
            }
        }).disposed(by: disposeBag)
    }
}
