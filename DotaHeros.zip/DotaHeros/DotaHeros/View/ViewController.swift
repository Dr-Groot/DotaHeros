//
//  ViewController.swift
//  DotaHeros
//
//  Created by Amam Pratap Singh on 16/02/23.
//

import UIKit
import RxSwift
import RxCocoa
import NVActivityIndicatorView

class ViewController: UIViewController {

    @IBOutlet var mainTableView: UITableView!

    private let viewModel = DotaViewModel()
    private let disposeBag = DisposeBag()

    private lazy var refreshControl: UIRefreshControl = {
            let refreshControl = UIRefreshControl()
        refreshControl.tintColor = .systemMint
            refreshControl.addTarget(
                self,
                action: #selector(handleRefresh),
                for: .valueChanged
            )
            return refreshControl
        }()

    override func viewDidLoad() {
        super.viewDidLoad()

        configTheme()
        configDependencies()
        addBindsToViewModel()
    }

    private func configTheme() {}

    private func configDependencies() {
        mainTableView.addSubview(refreshControl)
        viewModel.callDotaApi()

        mainTableView.register(cellType: DotaHeroCell.self)
        mainTableView.delegate = self
        mainTableView.dataSource = self
    }

    private func addBindsToViewModel() {
        viewModel.dotaApiStatus.asObservable().bind(onNext: { status in
            switch status {
            case .idle:
                print("Dota Api Idle State")
            case .progress:
                self.showLoader()
                print("Dota Api in Progress")
            case .success:
                self.hideLoader()
                self.refreshControl.endRefreshing()
                print("Dota Api Success")
            case .error:
                print("Error in Dota APi")
            }
        }).disposed(by: disposeBag)

        viewModel.dotaData.asObservable().bind(onNext: { _ in
            self.mainTableView.reloadData()
        }).disposed(by: disposeBag)
    }

    @objc private func handleRefresh(_ sender: UIRefreshControl) {
        refreshControl.beginRefreshing()
        viewModel.callDotaApi()
    }

}

extension ViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.dotaData.value?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let data = viewModel.dotaData.value?[indexPath.row]

        let cell = tableView.dequeueReusableCell(for: indexPath, cellType: DotaHeroCell.self)
        cell.setData(name: data?.localizedName ?? "", description: data?.name ?? "", Image: "https://api.opendota.com\(data?.icon ?? "")")

        cell.tapOpenButton = {
            let detailVC = self.storyboard?.instantiateViewController(withIdentifier: "DetailViewController") as! DetailViewController
            detailVC.modalPresentationStyle = .fullScreen
            detailVC.title = data?.localizedName ?? "Hero"
            detailVC.heroData = data
            self.navigationController?.pushViewController(detailVC, animated: true)
        }

        cell.selectionStyle = .none
        cell.backgroundColor = indexPath.row % 2 == 0 ? .systemGray5 : .white
        return cell
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }
}
